import os
from build_client import Trading212Client

client = Trading212Client()
critical_files = ['build_client.py', 'monday_preflight.py', 'verify_antigravity.py']
missing = [f for f in critical_files if not os.path.exists(f"/home/ubuntu/{f}")]

if missing:
    msg = f"⚠️ CRITICAL: Files missing on Oracle! {', '.join(missing)}. Restore from ORACLE_SNAPSHOT immediately."
    client.send_telegram(msg)
    print("Alert sent.")
else:
    print("All systems verified.")
