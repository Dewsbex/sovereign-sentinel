import os
import argparse
import requests
from trading212_client import Trading212Client

class JobCScalper:
    def __init__(self, test_orders=False):
        self.test_orders = test_orders
        self.client = Trading212Client()
        self.token = os.getenv('TELEGRAM_TOKEN')
        self.chat_id = os.getenv('TELEGRAM_CHAT_ID')

    def send_telegram(self, msg):
        if not self.token or not self.chat_id: return
        url = f"https://api.telegram.org/bot{self.token}/sendMessage"
        requests.post(url, json={"chat_id": self.chat_id, "text": msg, "parse_mode": "HTML"}, timeout=10)

    def cancel_all(self):
        print("🧹 Fetching open orders to cancel...")
        orders = self.client.get_open_orders()
        
        if not isinstance(orders, list):
            print(f"❌ Error fetching orders: {orders}")
            return

        if not orders:
            print("✅ No open orders found.")
            self.send_telegram("ℹ️ <b>Cancel All</b>: No open orders found.")
            return

        print(f"🔥 Found {len(orders)} open orders. Cancelling...")
        for order in orders:
            order_id = order.get('id')
            ticker = order.get('ticker', 'Unknown')
            
            # Execute Cancellation
            res = self.client.cancel_order(order_id)
            status = "CANCELLED" if res.get('status') == "OK" else "FAILED"
            
            # Notify
            msg = f"🛑 <b>{status}</b>: {ticker} (ID: {order_id})"
            print(msg)
            self.send_telegram(msg)

    def run(self, tickers=None):
        target_tickers = tickers if tickers else ["NVDA"]
        for t in target_tickers:
            print(f"📊 Processing: {t}")
            if self.test_orders:
                # Market
                m_res = self.client.place_market_order(t, 1)
                m_stat = m_res.get('status', 'FAILED')
                self.send_telegram(f"✅ <b>MARKET</b>: {t} - {m_stat}")
                
                # Limit
                l_res = self.client.place_limit_order(t, 1, limit_price=130.00)
                l_stat = l_res.get('status', 'FAILED')
                self.send_telegram(f"✅ <b>LIMIT</b>: {t} @ $130 - {l_stat}")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--live', action='store_true')
    parser.add_argument('--test-orders', action='store_true')
    parser.add_argument('--cancel-all', action='store_true')
    parser.add_argument('--tickers', nargs='+')
    args = parser.parse_args()
    
    scalper = JobCScalper(test_orders=args.test_orders)
    
    if args.cancel_all:
        scalper.cancel_all()
    else:
        scalper.run(tickers=args.tickers)

if __name__ == "__main__":
    main()
